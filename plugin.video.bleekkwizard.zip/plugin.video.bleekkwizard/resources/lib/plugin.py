#!/usr/bin/env python
'''
 *  Copyright (C) 2013
 *
 *  SPDX-License-Identifier: GPL-2.0-only
 *  See LICENSE.txt for more information.
'''

from xbmcswift2 import Plugin, xbmc, listitem
import xbmcgui,xbmcplugin,os,sys
import urllib,urllib.request
import re
import time
import downloader
import extract

#dialog = xbmcgui.Dialog() 

STRINGS = {
    #'editorials_recommendations': 30001,
    'no-pref': 30001
}
dialog = xbmcgui.Dialog()    
VERSION = "1.0.0"
PATH = "bleekk"  


plugin = Plugin()

#erstelle Startseite mit allen Builds aus wizard.html 
@plugin.route('/')
def show_root_menu():

    link = OPEN_URL('https://bleekk.github.io/kodi-wizard/bleekk-wiz.html').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    items=[]
    for name,url,img,fanart,description in match:
        addDir(name,url,1,img,fanart,description)
    return plugin.finish(items)

# 1. hole Inhalt von wizard.html
def OPEN_URL(url):
    with urllib.request.urlopen(url) as response:
        link=response.read().decode('utf-8')
    return link

# 2. erstelle Menüeinträge
def addDir(name,url,mode,img,fanart,description):
    # für debugging
    print ("Name: "+str(name))
    print ("URL: "+str(url))
    print ("IMG: "+str(img))
    print ("FANART: "+str(fanart))

    u=sys.argv[0]+"?url="+urllib.parse.quote(url)+"&mode="+str(mode)+"&name="+urllib.parse.quote(name)+"&iconimage="+urllib.parse.quote(img)+"&fanart="+urllib.parse.quote(fanart)+"&description="+urllib.parse.quote(description)
    ok=True
    liz = xbmcgui.ListItem(name)
    liz.setInfo( type='video', infoLabels={'title':name, 'plot':description} )
    liz.setArt( {'thumb':img, 'poster':img, 'fanart':fanart, 'icon':img} )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=str(u), listitem=liz, isFolder=False)
    return ok

def __log(text):
    plugin.log.info(text)


def __get_plugin_fanart():
    return plugin.fanart if not plugin.get_setting('hide-fanart', bool) else ''


def _(string_id):
    if string_id in STRINGS:
        return plugin.get_string(STRINGS[string_id])
    else:
        __log('String is missing: %s' % string_id)
        return string_id


# 3. sobald auf einen Link geklickt wurde, werden die Parameter aus dem Link gelesen
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

params = get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None

try:
        url=urllib.parse.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.parse.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.parse.unquote_plus(params["img"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.parse.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.parse.unquote_plus(params["description"])
except:
        pass
"""
# für debugging gedacht
print (str(PATH)+': '+str(VERSION))
print ("Mode: "+str(mode))
print ("URL: "+str(url))
print ("Name: "+str(name))
print ("IconImage: "+str(iconimage))
"""

# 4. Lade den Build runter
def wizard(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create('BLEKK Wizard', 'Bitte warten')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"ENTPACKE DATEIEN")
    print ('=======================================')
    print (addonfolder)
    print ('=======================================')
    extract.all(lib,addonfolder,dp)
    killxbmc()


# 5. nach dem Download biete die Option an Kodi zu schließen
def killxbmc():
    choice = xbmcgui.Dialog().yesno('[COLOR=orange]DOWNLOAD FERTIG[/COLOR]','Kodi muss geschlossen werden. Klicke OK um Kodi zu schließen.')
    if choice == 0:
        return
    elif choice == 1:
        pass
    myplatform = platform()
    print ("Platform: " + str(myplatform))
    if myplatform == 'osx': # OSX
        print ("############   try osx force close  #################")
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok("[COLOR=orange][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=orange]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'linux': #Linux
        print ("############   try linux force close  #################")
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok("[COLOR=orange][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=orange]DO NOT[/COLOR] exit cleanly via the menu.",'')
    elif myplatform == 'android': # Android  
        print ("############   try android force close  #################")
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass        
        dialog.ok("[COLOR=orange][B]WARNING  !!![/COLOR][/B]", "Your system has been detected as Android, you ", "[COLOR=orange][B]MUST[/COLOR][/B] force close XBMC/Kodi. [COLOR=orange]DO NOT[/COLOR] exit cleanly via the menu.","Either close using Task Manager (If unsure pull the plug).")
    elif myplatform == 'windows': # Windows
        print ("############   try windows force close  #################")
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        dialog.ok("[COLOR=orange][B]WARNUNG!!![/COLOR][/B]", "Wenn du diese Nachricht siehst bedeutet es; dass das gezwungende Schließen", "nicht erfolgreich war. Benutze den Task Manager um Kodi zu beenden","Verwende dazu NICHT das Menü im Kodi")
    else: #ATV
        print ("############   try atv force close  #################")
        try: os.system('killall AppleTV')
        except: pass
        print ("############   try raspbmc force close  #################") #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok("[COLOR=orange][B]WARNING  !!![/COLOR][/B]", "If you\'re seeing this message it means the force close", "was unsuccessful. Please force close XBMC/Kodi [COLOR=orange]DO NOT[/COLOR] exit via the menu.","Your platform could not be detected so just pull the power cable.")    

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'


# starte das Plugin, falls auf link geklickt wurde starte wizard()
if mode==None or url==None or len(url)<1:
        def run():
            try:
                plugin.run()
            except:
                plugin.notify(msg=_('etwas ist schiefgelaufen'))
       
elif mode==1:
        wizard(name,url,description)

"""
def run():
    try:
        plugin.run()
    except:
        plugin.notify(msg=_('etwas ist schiefgelaufen'))
"""